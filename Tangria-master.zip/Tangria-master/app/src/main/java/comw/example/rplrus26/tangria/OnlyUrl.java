package comw.example.rplrus26.tangria;

public class OnlyUrl {
}
